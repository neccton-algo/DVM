#!/bin/bash

rm -f output.nc var_list.txt var_list_2.txt

./gotm

cdo seltimestep,1 $1 temp_profile.nc
cdo chname,z,z_profile temp_profile.nc temp_profile_renamed.nc
cdo merge $1 temp_profile_renamed.nc output.nc 2>/dev/null

ncdump -h output.nc | grep 'float\|double\|int\|char' | awk '{print $2}' | sed 's/;//' > var_list.txt
grep '_2(' var_list.txt | sed 's/(.*//' > var_list_2.txt

while read var; do
  ncks -C -O -x -v $var output.nc temp.nc
  mv temp.nc output.nc
done < var_list_2.txt


rm temp_profile.nc temp_profile_renamed.nc var_list.txt var_list_2.txt
